@echo off
setlocal
title Spectral Audio
set "SpectralPS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "SpectralPS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%SpectralPS%" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Open-SpectralAudio.ps1" -Action Uninstall
set "SpectralExit=%errorlevel%"
if not "%SpectralExit%"=="0" if not "%SpectralExit%"=="2" pause
exit /b %SpectralExit%
